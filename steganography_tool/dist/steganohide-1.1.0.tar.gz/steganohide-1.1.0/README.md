# SteganoHide

Hide secret text messages inside perfectly normal-looking PNG images — and pull them back out again.

![SteganoHide in Action](demo.gif)

[![PyPI](https://img.shields.io/pypi/v/steganohide)](https://pypi.org/project/steganohide/)
[![Python](https://img.shields.io/pypi/pyversions/steganohide)](https://pypi.org/project/steganohide/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

**[→ Try it: Install from PyPI](https://pypi.org/project/steganohide/)**

---

## Quick Start

```bash
pip install steganohide
steganohide
```

That's it. The tool launches an interactive menu — no extra setup needed.

---

## Features

- **Encode** any text message into a standard PNG image with zero visible change
- **Decode** hidden messages back out of encoded images instantly
- Works on **any PNG image** — photos, screenshots, artwork, etc.
- Uses a **stop signal** so the decoder knows exactly where your message ends
- Simple **interactive CLI menu** — no flags or arguments to memorize
- Pure Python with a single dependency (Pillow)

---

## How to Run Locally

Requires **Python 3.8+**.

```bash
# Clone the repo
git clone https://github.com/ivadebandit/steganography-tool.git
cd steganography-tool

# Install dependencies
pip install pillow

# Run the tool
python steg_tool.py
```

You'll see:
```
================================
   Image Steganography Project
================================
1 - Hide a secret message (Encode)
2 - Reveal a secret message (Decode)

Enter 1 or 2:
```

---

## Example Usage

**Hiding a message:**
```
Enter 1 or 2: 1

--- ENCODER ---
Path to your original image (e.g. photo.png): examples/picture.png
Secret message to hide: meet me at midnight
Save encoded image as (e.g. secret.png): examples/secret.png

Success! Encoded image saved as: 'examples/secret.png'
To a human viewer it looks completely normal.
```

**Revealing it:**
```
Enter 1 or 2: 2

--- DECODER ---
Path to the encoded image (e.g. secret.png): examples/secret.png

Scanning image: 'examples/secret.png'
Reading hidden data from pixels...

Hidden message revealed: 'meet me at midnight'
```

---

## How It Works

Every PNG pixel has three color channels: Red, Green, and Blue (values 0–255).
The ASCII character set also maps every printable character to a number 0–127
— which fits perfectly inside that 0–255 range.

SteganoHide overwrites the Red channel of successive pixels with the ASCII
value of each character in your message. The human eye can't detect a
difference between a Red value of 82 (background color) and 72 (the letter 'H').
But Python can read it back precisely.

A **stop signal** (Red = 0) is written after the final character so the decoder
knows when to stop. The Green and Blue channels are never touched, preserving
the image's appearance.

```
'H' → ord('H') → 72  → stored in pixel (0,0) Red channel
'I' → ord('I') → 73  → stored in pixel (1,0) Red channel
 0  (stop)            → stored in pixel (2,0) Red channel
```

**Why PNG and not JPEG?**
JPEG compression is lossy — it rounds pixel values during save, destroying the
hidden data. PNG is lossless, so pixel values are preserved exactly after save.

---

## Project Structure

```
steganography-tool/
├── steg_tool.py       ← main CLI tool (encode + decode logic)
├── pyproject.toml     ← packaging config for PyPI
├── requirements.txt   ← Pillow dependency
├── LICENSE            ← MIT License
├── demo.gif           ← animated demo
└── examples/
    ├── picture.png    ← original input image
    └── secret.png     ← encoded output image
```

---

## Limitations

- Messages must be shorter than the total pixel count of the image
- Only works with PNG files (JPEG will corrupt the hidden data on save)
- Only ASCII characters are supported (values 0–127)
- A Red channel value of 0 in the original image will be mistaken for the stop signal — avoid pure black images

---

## Credits

Built with [Pillow](https://python-pillow.org/), the Python Imaging Library fork.

---

*Made for [Hack Club Stardance](https://stardance.hackclub.com/) — a summer of building real things.*
